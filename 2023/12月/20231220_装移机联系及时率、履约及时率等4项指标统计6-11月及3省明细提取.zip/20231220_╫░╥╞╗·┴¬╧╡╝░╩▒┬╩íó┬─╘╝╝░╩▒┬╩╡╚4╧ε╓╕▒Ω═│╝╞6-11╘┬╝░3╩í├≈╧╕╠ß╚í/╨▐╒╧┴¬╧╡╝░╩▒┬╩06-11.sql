set hive.mapred.mode = nonstrict;
set mapreduce.job.queuename = q_dc_dw;
------------统计结果
select busno_prov_id,
       busno_prov_name,
       '修障联系及时率'    as kpi_name,
       sum(case
               when round((unix_timestamp(accept_time, 'yyyyMMddHHmmss') - unix_timestamp(fitst_time)) / 60, 2) <
                    30 and kf_sn is not null or kf_sn = '' then 1
               else 0 end) as fenzi,
           count(1)            as fenmu,
       sum(case
               when round((unix_timestamp(accept_time, 'yyyyMMddHHmmss') - unix_timestamp(fitst_time)) / 60, 2) >
                    30 and kf_sn is not null or kf_sn = '' then 1
               else 0 end) as Late_arrival,
       sum(case
               when fitst_time is null or fitst_time = '' or kf_sn is null or kf_sn = '' or accept_time is null or
                    accept_time = '' then 1
               else 0 end) as iom_null --客服工单流水号 或 首次联系用户时间 为空值或null的
from (select *, row_number() over (partition by sheet_no order by fitst_time) as rn
      from (select sheet_no, sheet_id, accept_time, busno_prov_name, busno_prov_id
            from dc_dwa.dwa_d_sheet_main_history_chinese a
            where a.month_id = '202306'
              and a.is_delete = '0'
              and a.sheet_type = '04'
              and (
                pro_id not in ("S1", "S2", "N1", "N2")
                    or (
                    pro_id in ("S1", "S2", "N1", "N2")
                        and nvl(rc_sheet_code, "") = ""
                    )
                )
              and a.sheet_status = '7'
              and a.serv_type_name in (
                                       '故障工单（2021版）>>融合>>【网络使用】宽带网络>>宽带无法上网',
                                       '故障工单（2021版）>>融合>>【IPTV使用】IPTV>>IPTV无法观看',
                                       '故障工单（2021版）>>宽带>>【网络使用】宽带网络>>宽带无法上网',
                                       '故障工单（2021版）>>宽带>>【IPTV使用】IPTV>>IPTV无法观看',
                                       '故障工单（2021版）>>全语音门户自助报障>>全语音门户自助报障',
                                       '故障工单（2021版）>>全语音门户自助报障los红灯>>全语音门户自助报障los红灯',
                                       '故障工单（2021版）>>IVR自助报障>>IVR自助报障',
                                       '故障工单（2021版）>>融合>>【网络使用】宽带网络>>上网卡顿/掉线/延时/信号弱/不稳定/网页无法打开',
                                       '故障工单（2021版）>>融合>>【IPTV使用】IPTV>>IPTV播放卡顿',
                                       '故障工单（2021版）>>宽带>>【网络使用】宽带网络>>上网卡顿/掉线/延时/信号弱/不稳定/网页无法打开',
                                       '故障工单（2021版）>>宽带>>【IPTV使用】IPTV>>IPTV播放卡顿',
                                       '故障工单（2021版）>>全语音门户自助报障>>沃家电视障碍los灯亮红',
                                       '故障工单（2021版）>>IVR自助报障>>沃家电视障碍los灯亮红',
                                       '故障工单（2021版）>>融合>>【网络使用】宽带网络>>网速慢',
                                       '故障工单（2021版）>>融合>>【IPTV使用】IPTV>>TV设备故障',
                                       '故障工单（2021版）>>宽带>>【网络使用】宽带网络>>网速慢',
                                       '故障工单（2021版）>>宽带>>【IPTV使用】IPTV>>设备故障',
                                       '故障工单（2021版）>>全语音门户自助报障>>沃家电视障碍',
                                       '故障工单（2021版）>>IVR自助报障>>沃家电视障碍',
                                       '故障工单（2021版）>>融合>>【网络使用】宽带网络>>家庭WIFI信号弱/ 无法使用WIFI',
                                       '故障工单（2021版）>>宽带>>【网络使用】宽带网络>>家庭WIFI信号弱/ 无法使用WIFI',
                                       '故障工单（2021版）>>全语音门户自助报障>>宽带障碍los灯亮红',
                                       '故障工单（2021版）>>IVR自助报障>>宽带障碍los灯亮红',
                                       '故障工单（2021版）>>融合>>【网络使用】宽带网络>>网络速率与光猫路由不匹配',
                                       '故障工单（2021版）>>宽带>>【网络使用】宽带网络>>网络速率与光猫路由不匹配',
                                       '故障工单（2021版）>>全语音门户自助报障>>宽带障碍',
                                       '故障工单（2021版）>>IVR自助报障>>宽带障碍',
                                       '故障工单（2021版）>>融合>>【网络使用】宽带网络>>突发故障--宽带网络故障',
                                       '故障工单（2021版）>>宽带>>【网络使用】宽带网络>>突发故障--宽带网络故障'
                )) t1
               left join(select kf_sn, arrive_time, book_time, prov_id, province,fitst_time
                         from dc_dwd.dwd_m_evt_oss_insta_secur_gd
                         where month_id = '202306') t2
                        on t1.sheet_no = t2.kf_sn) t3
where rn = 1
group by busno_prov_id, busno_prov_name
order by busno_prov_id;


----明细结果
select sheet_no,
cust_area,
       cust_area_name,
       accept_time,
       deal_man,
       kf_sn,
       fitst_time,
       prov_id,
       province
from (select sheet_no, sheet_id, accept_time, cust_area, cust_area_name
      from dc_dwa.dwa_d_sheet_main_history_chinese a
      where a.month_id in ('202311')
        and cust_area_name = '上海'
        and a.is_delete = '0'
        and a.sheet_type = '04'
        and (pro_id not in ("S1", "S2", "N1", "N2")
          or (pro_id in ("S1", "S2", "N1", "N2")
              and nvl(rc_sheet_code, "") = ""))
        and a.sheet_status = '7'
        and a.serv_type_name in ('故障工单（2021版）>>融合>>【网络使用】宽带网络>>宽带无法上网',
                                 '故障工单（2021版）>>融合>>【IPTV使用】IPTV>>IPTV无法观看',
                                 '故障工单（2021版）>>宽带>>【网络使用】宽带网络>>宽带无法上网',
                                 '故障工单（2021版）>>宽带>>【IPTV使用】IPTV>>IPTV无法观看',
                                 '故障工单（2021版）>>全语音门户自助报障>>全语音门户自助报障',
                                 '故障工单（2021版）>>全语音门户自助报障los红灯>>全语音门户自助报障los红灯',
                                 '故障工单（2021版）>>IVR自助报障>>IVR自助报障',
                                 '故障工单（2021版）>>融合>>【网络使用】宽带网络>>上网卡顿/掉线/延时/信号弱/不稳定/网页无法打开',
                                 '故障工单（2021版）>>融合>>【IPTV使用】IPTV>>IPTV播放卡顿',
                                 '故障工单（2021版）>>宽带>>【网络使用】宽带网络>>上网卡顿/掉线/延时/信号弱/不稳定/网页无法打开',
                                 '故障工单（2021版）>>宽带>>【IPTV使用】IPTV>>IPTV播放卡顿',
                                 '故障工单（2021版）>>全语音门户自助报障>>沃家电视障碍los灯亮红',
                                 '故障工单（2021版）>>IVR自助报障>>沃家电视障碍los灯亮红',
                                 '故障工单（2021版）>>融合>>【网络使用】宽带网络>>网速慢',
                                 '故障工单（2021版）>>融合>>【IPTV使用】IPTV>>TV设备故障',
                                 '故障工单（2021版）>>宽带>>【网络使用】宽带网络>>网速慢',
                                 '故障工单（2021版）>>宽带>>【IPTV使用】IPTV>>设备故障',
                                 '故障工单（2021版）>>全语音门户自助报障>>沃家电视障碍',
                                 '故障工单（2021版）>>IVR自助报障>>沃家电视障碍',
                                 '故障工单（2021版）>>融合>>【网络使用】宽带网络>>家庭WIFI信号弱/ 无法使用WIFI',
                                 '故障工单（2021版）>>宽带>>【网络使用】宽带网络>>家庭WIFI信号弱/ 无法使用WIFI',
                                 '故障工单（2021版）>>全语音门户自助报障>>宽带障碍los灯亮红',
                                 '故障工单（2021版）>>IVR自助报障>>宽带障碍los灯亮红',
                                 '故障工单（2021版）>>融合>>【网络使用】宽带网络>>网络速率与光猫路由不匹配',
                                 '故障工单（2021版）>>宽带>>【网络使用】宽带网络>>网络速率与光猫路由不匹配',
                                 '故障工单（2021版）>>全语音门户自助报障>>宽带障碍',
                                 '故障工单（2021版）>>IVR自助报障>>宽带障碍',
                                 '故障工单（2021版）>>融合>>【网络使用】宽带网络>>突发故障--宽带网络故障',
                                 '故障工单（2021版）>>宽带>>【网络使用】宽带网络>>突发故障--宽带网络故障')) t1
         left join(select deal_man, kf_sn, fitst_time, prov_id, province
                   from dc_dwd.dwd_m_evt_oss_insta_secur_gd
                   where month_id = '202311') t2 on t1.sheet_no = t2.kf_sn;


